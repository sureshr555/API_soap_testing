
public class PojoObject {
public static void main(String[] args) {
	

	Pojo p=new Pojo();
	
	
	p.setDosageFormCd("sdf");
	p.setDosageFormType("sdgdf");
	p.setDrugClassType("sdfg");
	p.setDrugDefaultSig("dfg");
	p.setDrugStrength("dfgd");
	p.setGPI("sdgf");
	p.setNDC("sdf");
	p.setRouteOfAdminCodedVal("sdgdf");
	p.setSingleActiveIngredientInd("sdf");

	
	p.getDosageFormCd();
	p.getDosageFormType();
	p.getDrugClassType();
	p.getDrugDefaultSig();
	p.getDrugStrength();
	p.getGPI();
p.getNDC();
p.getRouteOfAdminCodedVal();
p.getSingleActiveIngredientInd();



}
}